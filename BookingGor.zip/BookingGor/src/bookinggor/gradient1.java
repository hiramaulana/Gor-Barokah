package bookinggor;


import java.awt.Color;
import java.awt.GradientPaint;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;


/**
 *
 * @author Maulana 203
 */
public class gradient1 extends JPanel{
    public void paintComponent(Graphics g){
        Graphics2D gd = (Graphics2D) g.create();
        gd.setPaint(new GradientPaint(25, 25, Color.white, 10, getHeight(), Color.white));
        gd.fillRect(0, 0, getWidth(), getHeight());
    }
}
